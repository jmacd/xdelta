# Xdelta Binary Distribution

Version: 3.1.0

## Contents

- x64-windows/
  - bin/
    - xdelta3.exe - Release build
    - xdelta3d.exe - Debug build (if available)
  - lib/
    - xdelta.lib - Release build
    - xdeltad.lib - Debug build (if available)
  - include/xdelta3/
    - xdelta3.h
    - xdelta3.c
- x86-windows/
  - bin/
    - xdelta3.exe - Release build
    - xdelta3d.exe - Debug build (if available)
  - lib/
    - xdelta.lib - Release build
    - xdeltad.lib - Debug build (if available)
  - include/xdelta3/
    - xdelta3.h
    - xdelta3.c

## Usage

### Command Line

`
xdelta3.exe -h
`

### Library

Include xdelta3.h in your project and link against xdelta.lib.

## License

Licensed under the Apache License, Version 2.0
