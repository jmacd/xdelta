# Using Xdelta with vcpkg

This package provides the xdelta3 command-line tool and header files for use with vcpkg.

## Command-line Usage

The xdelta3 executable is available at:
- \/\/tools/xdelta/xdelta3.exe

## Including in Your Project

To use xdelta in your C/C++ project:

`cpp
#include <xdelta3/xdelta3.h>
`

For more information, see the [official documentation](https://github.com/jmacd/xdelta/blob/wiki/CommandLineSyntax.md).
