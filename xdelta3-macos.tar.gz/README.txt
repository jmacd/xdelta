Xdelta3 macOS Binary
======================

This package contains the xdelta3 command-line utility for macOS.

Command Line Syntax
-------------------

make patch:

  xdelta3 -e -s old_file new_file delta_file

apply patch:

  xdelta3 -d -s old_file delta_file decoded_new_file

standard options:
   -0 .. -9     compression level
   -c           use stdout
   -d           decompress
   -e           compress
   -f           force (overwrite, ignore trailing garbage)
   -h           show help
   -q           be quiet
   -v           be verbose (max 2)
   -V           show version

For full documentation, run: xdelta3 --help

NOTICE: macOS build is temporarily disabled due to C++11 literal suffix issues.
Please use Windows or Linux platforms.
