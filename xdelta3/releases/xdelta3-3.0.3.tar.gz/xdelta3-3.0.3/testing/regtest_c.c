/* -*- Mode: C++ -*-  */
#include "../xdelta3.c"
