# This file was created automatically by SWIG.
# Don't modify this file, modify the SWIG interface instead.
# This file is compatible with both classic and new-style classes.

import _xdelta3

def _swig_setattr_nondynamic(self,class_type,name,value,static=1):
    if (name == "this"):
        if isinstance(value, class_type):
            self.__dict__[name] = value.this
            if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
            del value.thisown
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    if (not static) or hasattr(self,name) or (name == "thisown"):
        self.__dict__[name] = value
    else:
        raise AttributeError("You cannot add attributes to %s" % self)

def _swig_setattr(self,class_type,name,value):
    return _swig_setattr_nondynamic(self,class_type,name,value,0)

def _swig_getattr(self,class_type,name):
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0
del types



xd3_encode_memory = _xdelta3.xd3_encode_memory

xd3_decode_memory = _xdelta3.xd3_decode_memory

xd3_main_cmdline = _xdelta3.xd3_main_cmdline
XD3_SEC_DJW = _xdelta3.XD3_SEC_DJW
XD3_SEC_FGK = _xdelta3.XD3_SEC_FGK
XD3_SEC_NODATA = _xdelta3.XD3_SEC_NODATA
XD3_SEC_NOINST = _xdelta3.XD3_SEC_NOINST
XD3_SEC_NOADDR = _xdelta3.XD3_SEC_NOADDR
XD3_ADLER32 = _xdelta3.XD3_ADLER32
XD3_ADLER32_NOVER = _xdelta3.XD3_ADLER32_NOVER
XD3_ALT_CODE_TABLE = _xdelta3.XD3_ALT_CODE_TABLE
XD3_NOCOMPRESS = _xdelta3.XD3_NOCOMPRESS
XD3_BEGREEDY = _xdelta3.XD3_BEGREEDY
XD3_COMPLEVEL_SHIFT = _xdelta3.XD3_COMPLEVEL_SHIFT
XD3_COMPLEVEL_MASK = _xdelta3.XD3_COMPLEVEL_MASK
XD3_COMPLEVEL_1 = _xdelta3.XD3_COMPLEVEL_1
XD3_COMPLEVEL_3 = _xdelta3.XD3_COMPLEVEL_3
XD3_COMPLEVEL_6 = _xdelta3.XD3_COMPLEVEL_6
XD3_COMPLEVEL_9 = _xdelta3.XD3_COMPLEVEL_9

